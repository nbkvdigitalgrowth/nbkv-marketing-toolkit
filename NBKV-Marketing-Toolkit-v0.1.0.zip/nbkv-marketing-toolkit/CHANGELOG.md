# Changelog

## 0.1.0 — Initial project draft

- Added UTM link builder.
- Added Meta Ads and Google Ads campaign naming helper.
- Added CTR, CPC, CPM, and cost-per-lead calculator.
- Added project documentation, contribution guidelines, and MIT license.
