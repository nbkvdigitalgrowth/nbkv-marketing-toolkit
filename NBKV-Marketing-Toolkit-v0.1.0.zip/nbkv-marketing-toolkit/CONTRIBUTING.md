# Contributing

Thank you for considering a contribution to NBKV Marketing Toolkit.

## Ways to contribute

- Report a reproducible bug.
- Suggest a practical marketing workflow or calculator.
- Improve accessibility, mobile usability, or documentation.
- Submit a focused pull request.

## Before opening a pull request

1. Open `index.html` in a current browser and test the changed workflow.
2. Check the page at desktop and mobile widths.
3. Confirm keyboard navigation and visible focus states still work.
4. Do not add trackers, analytics, hidden network requests, API keys, or personal data collection.
5. Keep changes small and explain the user problem they solve.

## Pull request checklist

- [ ] The change has a clear purpose.
- [ ] Existing tools still work.
- [ ] Inputs are validated and errors are understandable.
- [ ] No sensitive information or credentials are included.
- [ ] Documentation is updated where needed.
