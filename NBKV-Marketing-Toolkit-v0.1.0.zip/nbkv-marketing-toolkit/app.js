'use strict';

const byId = (id) => document.getElementById(id);
const safeText = (value) => String(value ?? '').trim();

function setError(id, message) {
  byId(id).textContent = message;
}

function copyText(text, button, successLabel) {
  if (!text) return;
  const original = button.textContent;
  const done = () => {
    button.textContent = successLabel;
    window.setTimeout(() => { button.textContent = original; }, 1600);
  };
  if (navigator.clipboard && window.isSecureContext) {
    navigator.clipboard.writeText(text).then(done).catch(() => fallbackCopy(text, done));
  } else {
    fallbackCopy(text, done);
  }
}

function fallbackCopy(text, onSuccess) {
  const field = document.createElement('textarea');
  field.value = text;
  field.setAttribute('readonly', '');
  field.style.position = 'fixed';
  field.style.opacity = '0';
  document.body.appendChild(field);
  field.select();
  try {
    if (document.execCommand('copy')) onSuccess();
  } finally {
    field.remove();
  }
}

let generatedUrl = '';
byId('utm-form').addEventListener('submit', (event) => {
  event.preventDefault();
  setError('utm-error', '');
  const rawUrl = safeText(byId('utm-url').value);
  const source = safeText(byId('utm-source').value);
  const medium = safeText(byId('utm-medium').value);
  const campaign = safeText(byId('utm-campaign').value);
  if (!rawUrl || !source || !medium || !campaign) {
    setError('utm-error', 'Please complete the URL, source, medium, and campaign name.');
    return;
  }
  let url;
  try {
    url = new URL(rawUrl);
    if (!['http:', 'https:'].includes(url.protocol)) throw new Error('Unsupported protocol');
  } catch {
    setError('utm-error', 'Enter a valid http:// or https:// website URL.');
    return;
  }
  const params = {
    utm_source: source,
    utm_medium: medium,
    utm_campaign: campaign,
    utm_term: safeText(byId('utm-term').value),
    utm_content: safeText(byId('utm-content').value)
  };
  Object.entries(params).forEach(([key, value]) => {
    if (value) url.searchParams.set(key, value);
  });
  generatedUrl = url.toString();
  byId('utm-output').textContent = generatedUrl;
  byId('utm-copy').disabled = false;
});

byId('utm-form').addEventListener('reset', () => {
  generatedUrl = '';
  byId('utm-output').textContent = 'Your generated URL will appear here.';
  byId('utm-copy').disabled = true;
  setError('utm-error', '');
});
byId('utm-copy').addEventListener('click', () => copyText(generatedUrl, byId('utm-copy'), 'Copied ✓'));

function slug(value) {
  return safeText(value).toUpperCase().replace(/[^A-Z0-9]+/g, '_').replace(/^_+|_+$/g, '') || 'NA';
}
function updateCampaignName() {
  const dateValue = byId('campaign-date').value;
  const date = dateValue ? dateValue.replaceAll('-', '') : 'YYYYMMDD';
  const parts = [
    byId('platform').value,
    byId('objective').value,
    slug(byId('location').value),
    slug(byId('audience').value),
    byId('creative').value,
    date,
    slug(byId('version').value)
  ];
  byId('name-output').textContent = parts.join('_');
}
byId('naming-form').addEventListener('submit', (event) => {
  event.preventDefault();
  updateCampaignName();
});
byId('naming-form').addEventListener('input', updateCampaignName);
byId('naming-form').addEventListener('change', updateCampaignName);
byId('naming-form').addEventListener('reset', () => window.setTimeout(updateCampaignName, 0));
byId('name-copy').addEventListener('click', () => copyText(byId('name-output').textContent, byId('name-copy'), 'Copied ✓'));

function readNonNegativeNumber(id) {
  const raw = safeText(byId(id).value);
  if (raw === '') return null;
  const number = Number(raw);
  return Number.isFinite(number) && number >= 0 ? number : null;
}
function metricValue(value, suffix = '') {
  return value === null || !Number.isFinite(value) ? '—' : `${value.toLocaleString('en-IN', { maximumFractionDigits: 2 })}${suffix}`;
}
byId('kpi-form').addEventListener('submit', (event) => {
  event.preventDefault();
  setError('kpi-error', '');
  const spend = readNonNegativeNumber('spend');
  const impressions = readNonNegativeNumber('impressions');
  const clicks = readNonNegativeNumber('clicks');
  const leads = readNonNegativeNumber('leads');
  if ([spend, impressions, clicks, leads].some((value) => value === null)) {
    setError('kpi-error', 'Enter valid non-negative numbers in all four fields.');
    return;
  }
  if (clicks > impressions) {
    setError('kpi-error', 'Link clicks cannot exceed impressions. Please check your inputs.');
    return;
  }
  const values = [
    metricValue(impressions > 0 ? clicks / impressions * 100 : null, '%'),
    metricValue(clicks > 0 ? spend / clicks : null, ' ₹'),
    metricValue(impressions > 0 ? spend / impressions * 1000 : null, ' ₹'),
    metricValue(leads > 0 ? spend / leads : null, ' ₹')
  ];
  const notes = ['Clicks ÷ impressions', 'Spend ÷ clicks', 'Spend ÷ impressions × 1,000', 'Spend ÷ leads'];
  const labels = ['CTR', 'CPC', 'CPM', 'Cost per lead'];
  byId('metrics').innerHTML = values.map((value, index) =>
    `<div class="metric"><span>${labels[index]}</span><strong>${value}</strong><small>${notes[index]}</small></div>`
  ).join('');
});
byId('kpi-form').addEventListener('reset', () => {
  setError('kpi-error', '');
  byId('metrics').innerHTML = `
    <div class="metric"><span>CTR</span><strong>—</strong><small>Clicks ÷ impressions</small></div>
    <div class="metric"><span>CPC</span><strong>—</strong><small>Spend ÷ clicks</small></div>
    <div class="metric"><span>CPM</span><strong>—</strong><small>Spend ÷ impressions × 1,000</small></div>
    <div class="metric"><span>Cost per lead</span><strong>—</strong><small>Spend ÷ leads</small></div>`;
});

byId('year').textContent = new Date().getFullYear();
updateCampaignName();
